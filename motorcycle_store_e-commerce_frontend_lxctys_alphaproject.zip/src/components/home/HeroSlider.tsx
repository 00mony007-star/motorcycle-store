import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '../ui/Button';

const slides = [
  {
    id: 1,
    image: 'https://images.unsplash.com/photo-1558981403-c5f9899a28bc?q=80&w=2070&auto=format&fit=crop',
    title: 'Ride with Confidence',
    subtitle: 'Explore our collection of premium, safety-certified helmets.',
    link: '/category/helmets',
    cta: 'Shop Helmets',
  },
  {
    id: 2,
    image: 'https://images.unsplash.com/photo-1617833419017-230991371813?q=80&w=2070&auto=format&fit=crop',
    title: 'Unmatched Style & Protection',
    subtitle: 'From leather to textile, find the perfect jacket for any weather.',
    link: '/category/jackets',
    cta: 'Discover Jackets',
  },
  {
    id: 3,
    image: 'https://images.unsplash.com/photo-1599749293224-63e5d045109f?q=80&w=1974&auto=format&fit=crop',
    title: 'The Open Road Awaits',
    subtitle: 'Get the best gear for your next adventure.',
    link: '/category/all',
    cta: 'Explore All Gear',
  },
];

const textVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: 'easeOut' } },
  exit: { opacity: 0, y: -20, transition: { duration: 0.4, ease: 'easeIn' } },
};

const imageVariants = {
    hidden: { opacity: 0, scale: 1.1 },
    visible: { opacity: 1, scale: 1, transition: { duration: 1, ease: [0.43, 0.13, 0.23, 0.96] } },
    exit: { opacity: 0, scale: 1.05, transition: { duration: 0.7, ease: [0.43, 0.13, 0.23, 0.96] } },
};

export function HeroSlider() {
  const [currentIndex, setCurrentIndex] = useState(0);

  const nextSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % slides.length);
  };

  const prevSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex - 1 + slides.length) % slides.length);
  };
  
  const goToSlide = (index: number) => {
    setCurrentIndex(index);
  };

  useEffect(() => {
    const timer = setTimeout(nextSlide, 7000);
    return () => clearTimeout(timer);
  }, [currentIndex]);

  const currentSlide = slides[currentIndex];

  return (
    <section className="relative h-[60vh] md:h-[80vh] w-full overflow-hidden text-white">
      <AnimatePresence initial={false}>
        <motion.div
          key={currentIndex}
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${currentSlide.image})` }}
          variants={imageVariants}
          initial="hidden"
          animate="visible"
          exit="exit"
        >
             <motion.div 
                className="absolute inset-0"
                style={{backgroundImage: 'linear-gradient(to top, rgba(0,0,0,0.6), rgba(0,0,0,0.2))'}}
            />
        </motion.div>
      </AnimatePresence>

      <div className="relative z-10 flex flex-col items-center justify-center h-full text-center p-4">
        <AnimatePresence mode="wait">
            <motion.div key={currentIndex}>
                <motion.h1
                    className="text-4xl md:text-6xl font-bold tracking-tight mb-4 drop-shadow-lg"
                    variants={textVariants}
                    initial="hidden"
                    animate="visible"
                    exit="exit"
                >
                    {currentSlide.title}
                </motion.h1>
                <motion.p
                    className="text-lg md:text-xl max-w-3xl mx-auto mb-8 drop-shadow-md"
                    variants={textVariants}
                    initial="hidden"
                    animate="visible"
                    exit="exit"
                >
                    {currentSlide.subtitle}
                </motion.p>
                <motion.div
                    variants={textVariants}
                    initial="hidden"
                    animate="visible"
                    exit="exit"
                >
                    <Button asChild size="lg">
                        <Link to={currentSlide.link}>{currentSlide.cta}</Link>
                    </Button>
                </motion.div>
            </motion.div>
        </AnimatePresence>
      </div>

      {/* Navigation Arrows */}
      <button
        onClick={prevSlide}
        className="absolute left-4 top-1/2 -translate-y-1/2 z-20 bg-black/30 text-white p-2 rounded-full hover:bg-black/50 transition-colors focus-ring"
        aria-label="Previous slide"
      >
        <ChevronLeft size={28} />
      </button>
      <button
        onClick={nextSlide}
        className="absolute right-4 top-1/2 -translate-y-1/2 z-20 bg-black/30 text-white p-2 rounded-full hover:bg-black/50 transition-colors focus-ring"
        aria-label="Next slide"
      >
        <ChevronRight size={28} />
      </button>
      
      {/* Pagination Dots */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-20 flex space-x-3">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => goToSlide(index)}
            className={`w-3 h-3 rounded-full transition-colors ${
              currentIndex === index ? 'bg-white' : 'bg-white/50 hover:bg-white/75'
            }`}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>
    </section>
  );
}
