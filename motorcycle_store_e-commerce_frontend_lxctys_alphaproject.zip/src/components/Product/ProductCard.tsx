import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { Product } from '../../lib/types'
import { formatCurrency } from '../../lib/utils'
import { Button } from '../ui/Button'
import { Card, CardContent } from '../ui/Card'
import { StarRating } from '../ui/StarRating'
import { Badge } from '../ui/Badge'
import { ShoppingCart, Loader2, Check } from 'lucide-react'
import { useCartStore } from '../../lib/stores/cartStore'
import { useTranslation } from 'react-i18next'
import { motion } from 'framer-motion'

interface ProductCardProps {
  product: Product
}

export function ProductCard({ product }: ProductCardProps) {
  const addItemToCart = useCartStore((state) => state.addItem)
  const { t } = useTranslation()
  const [addStatus, setAddStatus] = useState<'idle' | 'loading' | 'success'>('idle')

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (addStatus !== 'idle') return

    setAddStatus('loading')
    setTimeout(() => {
      addItemToCart(product)
      setAddStatus('success')
      setTimeout(() => setAddStatus('idle'), 2000)
    }, 500)
  }

  const getButtonContent = () => {
    switch (addStatus) {
      case 'loading':
        return <Loader2 className="h-4 w-4 animate-spin" />
      case 'success':
        return <><Check className="me-2 h-4 w-4" /> {t('product.added')}</>
      case 'idle':
      default:
        return <><ShoppingCart className="me-2 h-4 w-4" /> {product.stock > 0 ? t('product.addToCart') : t('product.outOfStock')}</>
    }
  }

  return (
    <motion.div whileHover={{ y: -5 }} className="h-full">
      <Card className="w-full h-full flex flex-col overflow-hidden group transition-all duration-300 hover:shadow-lg hover:border-primary hover:shadow-glow-primary">
        <Link to={`/product/${product.slug}`} className="flex flex-col flex-grow">
          <CardContent className="p-0 flex flex-col flex-grow">
            <div className="relative">
              <img
                src={product.images[0]}
                alt={product.title}
                className="w-full h-64 object-cover transition-transform duration-300 group-hover:scale-105"
              />
              {product.compareAtPrice && (
                <Badge variant="destructive" className="absolute top-3 start-3">
                  {t('product.sale')}
                </Badge>
              )}
              {product.featured && (
                <Badge variant="secondary" className="absolute top-3 end-3">
                  {t('product.featured')}
                </Badge>
              )}
            </div>
            <div className="p-4 space-y-2 flex flex-col flex-grow">
              <p className="text-sm text-muted-foreground">{product.brand}</p>
              <h3 className="font-semibold text-lg truncate flex-grow">{product.title}</h3>
              <div className="flex items-center justify-between pt-2">
                <div className="flex items-center space-x-2">
                  <p className="text-xl font-bold text-primary">
                    {formatCurrency(product.price)}
                  </p>
                  {product.compareAtPrice && (
                    <p className="text-sm text-muted-foreground line-through">
                      {formatCurrency(product.compareAtPrice)}
                    </p>
                  )}
                </div>
                <div className="flex items-center space-x-1">
                  <StarRating rating={product.rating} />
                  <span className="text-xs text-muted-foreground">({product.reviewCount})</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Link>
        <div className="p-4 pt-0 mt-auto">
          <Button
            className="w-full"
            onClick={handleAddToCart}
            aria-label={`Add ${product.title} to cart`}
            disabled={product.stock === 0 || addStatus !== 'idle'}
            variant={addStatus === 'success' ? 'secondary' : 'default'}
          >
            {getButtonContent()}
          </Button>
        </div>
      </Card>
    </motion.div>
  )
}
