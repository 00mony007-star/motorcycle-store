import React from 'react'
import ReactECharts from 'echarts-for-react'
import { Order } from '../../lib/types'
import { formatCurrency } from '../../lib/utils'

interface SalesChartProps {
  orders: Order[]
}

export function SalesChart({ orders }: SalesChartProps) {
  const salesData = orders
    .filter(o => o.status === 'delivered' || o.status === 'shipped')
    .reduce((acc, order) => {
      const date = new Date(order.createdAt).toISOString().split('T')[0]
      acc[date] = (acc[date] || 0) + order.total
      return acc
    }, {} as Record<string, number>)

  const sortedDates = Object.keys(salesData).sort((a, b) => new Date(a).getTime() - new Date(b).getTime())

  const chartOption = {
    tooltip: {
      trigger: 'axis',
      formatter: (params: any) => {
        const data = params[0]
        return `${data.axisValue}<br/>Sales: ${formatCurrency(data.value)}`
      }
    },
    xAxis: {
      type: 'category',
      data: sortedDates,
    },
    yAxis: {
      type: 'value',
      axisLabel: {
        formatter: (value: number) => formatCurrency(value, 'USD').replace('$', '')
      }
    },
    series: [
      {
        data: sortedDates.map(date => salesData[date]),
        type: 'line',
        smooth: true,
      },
    ],
    grid: {
      left: '3%',
      right: '4%',
      bottom: '3%',
      containLabel: true
    }
  }

  return <ReactECharts option={chartOption} style={{ height: '400px' }} />
}
